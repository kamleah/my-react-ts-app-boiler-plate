export const BASE_URL = 'http://74.234.200.47/';
export const API_IMAGE_URL = 'http://74.234.200.47';
export const API_VERSION = 'v1';