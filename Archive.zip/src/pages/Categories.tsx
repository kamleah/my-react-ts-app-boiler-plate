import CategoryList from '../features/list/CategoryList'

const Categories = () => {
  return (
    <CategoryList />
  )
}

export default Categories