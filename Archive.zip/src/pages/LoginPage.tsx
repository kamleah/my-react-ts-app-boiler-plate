import React from 'react';
import { Login } from '../features';

const LoginPage: React.FC = () => (
    <Login />
);

export default LoginPage;